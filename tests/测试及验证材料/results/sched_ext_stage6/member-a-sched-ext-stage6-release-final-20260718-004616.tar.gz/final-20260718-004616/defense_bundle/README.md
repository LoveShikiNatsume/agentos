# AgentOS sched_ext Stage 6 Defense Bundle

本包证明 Linux sched_ext partial mode 仅接管显式绑定的 Agent Worker，并提供异常回退证据。

允许表述：真实 partial takeover、三级 DSQ、策略消费、自动回退。

禁止表述：替换 Linux 全部调度器、接管 RT、达到生产级。

验证：`python scripts/verify_sched_ext_stage6_release.py --bundle <stage6_release> --frozen --json`
